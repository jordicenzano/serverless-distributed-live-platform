exports.handler = (event, context, callback) => {
    console.log('This is an empty lambda, you need to upload some code!');
    callback(null, 'Lambda complete!');
};
